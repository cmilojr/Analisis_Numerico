from Interfaz import Interfaz
class Ejecutable:
    if __name__ == "__main__":
        interface=Interfaz()
        Interfaz().run()