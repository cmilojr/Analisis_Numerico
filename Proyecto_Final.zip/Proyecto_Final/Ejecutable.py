from Graficador import Graficador

class Ejecutable:
    
    if __name__ == "__main__":
        prueba=Graficador()
        prueba.menu_capitulos()
        prueba.root.mainloop()
        
